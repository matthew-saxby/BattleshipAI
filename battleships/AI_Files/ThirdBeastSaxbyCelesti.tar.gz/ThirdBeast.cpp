/**
 * @file ThirdBeast.cpp
 * @author mathew Saxby David Celesti
 * @brief The starter file
 * @date 2024-5-06
 */

#include "ThirdBeast.h"

#include <cstdlib> 
#include <ctime>   


// Write your AI's name here. Please don't make it more than 64 bytes.
#define AI_NAME "ThirdBeast"

// Write your name(s) here. Please don't make it more than 64 bytes.
#define AUTHOR_NAMES "David Celesti, Mathew Saxby"


/*================================================================================
 * Starts up the entire match. Do NOT change anything here unless you really understand
 * what you are doing.
 *================================================================================*/
int main(int argc, char *argv[]) {
    // player must have the socket path as an argument.
    if ( argc != 2 ) {
        printf("%s Error: Requires socket name! (line: %d)\n", AI_NAME, __LINE__);
        return -1;
    }
    char *socket_path = argv[1];
    
    // set random seed
    srand(getpid());

    ThirdBeast my_player = ThirdBeast();
    return my_player.play_match(socket_path, AI_NAME, AUTHOR_NAMES);
}

ThirdBeast::ThirdBeast():Player() {
    return;
}

ThirdBeast::~ThirdBeast() {
    return;
}

/*================================================================================
 * This is like a constructor for the entire match.
 * You probably don't want to make changes here unless it is something that is done once at the beginning 
 * of the entire match..
 *================================================================================*/
void ThirdBeast::handle_setup_match(PlayerNum player, int board_size) {
    this->player = player;
    this->board_size = board_size;
    create_boards();
    return;
}

/*================================================================================
 * This is like a constructor for one game/round within the entire match.
 * Add anything here that you need to do at the beginning of each game.
 *================================================================================*/
void ThirdBeast::handle_start_game() {
    clear_boards();
    return;
}

/*================================================================================
 Randomly placing Ships
 *================================================================================*/
Ship ThirdBeast::choose_ship_place(int ship_length) {
    srand(time(NULL));
    Ship ship;
    ship.len = ship_length;
    ship.row = 0;
    ship.col = 0;
    ship.dir = VERTICAL;
    bool ship_okay = false;

 while (!ship_okay) {
        ship.row = rand() % this->board_size; // Random row
        ship.col = rand() % this->board_size; // Random column
        ship.dir = rand() % 2 == 0 ? HORIZONTAL : VERTICAL; // Random direction

        ship_okay = true;


        //make sure in bounds
        if (ship.dir == HORIZONTAL) {
            if (ship.col + ship.len > this->board_size) {
                ship_okay = false;
            } 
            else {
                for (int len = 0; len < ship.len; len++) {
                    //check overlap
                    if (this->ship_board[ship.row][ship.col + len] != WATER) {
                        ship_okay = false;
                        break;
                    }
                }
            }
        } 
        //for vertical
        else {
            //make sure in bounds
            if (ship.row + ship.len > this->board_size) {
                ship_okay = false;
            } 
            else {
                for (int len = 0; len < ship.len; len++) {
                    // make sure not overlapping
                    if (this->ship_board[ship.row + len][ship.col] != WATER) {
                        ship_okay = false;
                        break;
                    }
                }
            }
        }

        //if placement is good then go forr it
        if (ship_okay) {
            if (ship.dir == HORIZONTAL) {
                for (int len = 0; len < ship.len; len++) {
                    this->ship_board[ship.row][ship.col + len] = SHIP;
                }
            } 
            if(ship.dir == VERTICAL) {
                for (int len = 0; len < ship.len; len++) {
                    this->ship_board[ship.row + len][ship.col] = SHIP;
                }
            }
            return ship;
        }
    }
    return ship;
}


int ThirdBeast::hVal(int row, int col) {
    if (row < 0 || row >= board_size || col < 0 || col >= board_size || shot_board[row][col] != WATER)
        return -100; // Out of bounds or already shot at

    int width = 1;
    int bonus = 0;

    // Check to the right
    for (int i = 1; i < 4; i++) {
        if (col + i < board_size) {
            char ch = shot_board[row][col + i];
            if (ch == MISS || ch == KILL)
                break;
            if (ch == WATER || ch == HIT)
                width++;
            if (ch == HIT)
                bonus += 10;
        }
    }

    // Check to the left
    for (int i = 1; i < 4; i++) {
        if (col - i >= 0) {
            char ch = shot_board[row][col - i];
            if (ch == MISS || ch == KILL)
                break;
            if (ch == WATER || ch == HIT)
                width++;
            if (ch == HIT)
                bonus += 10;
        }
    }

    if (width < 3)
        return 0;
    else
        return width + bonus;
}

int ThirdBeast::vVal(int row, int col) {
    if (row < 0 || row >= board_size || col < 0 || col >= board_size || shot_board[row][col] != WATER)
        return -100; // Out of bounds or already shot at

    int height = 1;
    int bonus = 0;

    // Check upwards
    for (int i = 1; i < 4; i++) {
        if (row + i < board_size) {
            char ch = shot_board[row + i][col];
            if (ch == MISS || ch == KILL)
                break;
            if (ch == WATER || ch == HIT)
                height++;
            if (ch == HIT)
                bonus += 10;
        }
    }

    // Check downwards
    for (int i = 1; i < 4; i++) {
        if (row - i >= 0) {
            char ch = shot_board[row - i][col];
            if (ch == MISS || ch == KILL)
                break;
            if (ch == WATER || ch == HIT)
                height++;
            if (ch == HIT)
                bonus += 10;
        }
    }

    if (height < 3)
        return 0;
    else
        return height + bonus;
}

/*================================================================================
 how to decide where to shoot and inform the contest controller
 *================================================================================*/
Shot ThirdBeast::choose_shot() {
    Shot shot;
    shot.row = 0;
    shot.col = 0;
    int best_val=-1000;
    

    for (int row = 0; row < this->board_size; row++) {
        for (int col = 0; col < this->board_size; col++) {
            int val = hVal(row,col) + vVal(row,col);
            if( val > best_val ){
                best_val=val;
                shot.row=row;
                shot.col=col;
            }
        }
    }
    return shot;
   

}



/*================================================================================
 * This function is called to inform your AI of the result o}f a previous shot,
 * as well as where the opponent has shot.
 *========================================================:========================*/
void ThirdBeast::handle_shot_return(PlayerNum player, Shot &shot) {
    // Results of your AI's shot was returned, store it
    if ( player == this->player ) {
        this->shot_board[shot.row][shot.col] = shot.value;

    }

    // Your AI is informed of where the opponent AI shot, store it
    // NOTE: Opponent shots are stored in ship_board, not shot_board
    else {
        this->ship_board[shot.row][shot.col] = shot.value;
    }
    return;
}

/*================================================================================
 * This function is called to update your shot_board (results of your shots at
 * opponent) when an opponent ship has been killed, OR to update your ship_board
 * (where you keep track of your ships) to show that your ship was killed.
 *================================================================================*/
void ThirdBeast::handle_ship_dead(PlayerNum player, Ship &ship) {
    // store the ship that was killed
    for (int i = 0; i < ship.len; i++) {
        if ( player == this->player ) { // your ship is dead
            if      (ship.dir == HORIZONTAL) {
                this->ship_board[ship.row][ship.col+i] = KILL;
                //this->prob_board[ship.row][ship.col+i] = KILL;
            }
            else if (ship.dir == VERTICAL)   {
                this->ship_board[ship.row+i][ship.col] = KILL;
                //this->prob_board[ship.row+i][ship.col] = KILL;
            }    
        } else {             // their ship is dead
            if      (ship.dir == HORIZONTAL) {
                this->shot_board[ship.row][ship.col+i] = KILL;
               // this->prob_board[ship.row][ship.col+i] = KILL;
            }
            else if (ship.dir == VERTICAL)   {
                this->shot_board[ship.row+i][ship.col] = KILL;
               // this->prob_board[ship.row+i][ship.col] = KILL;
            }
        }

    }
    return;
}

/*================================================================================
 * This function runs at the end of a particular game/round.
 * Do anything here that needs to be done at the end of a game/round in the match.
 *================================================================================*/
void ThirdBeast::handle_game_over() {
    return;
}

/*================================================================================
 * This function is called by the AI's destructor and runs at the end of the entire match.
 *================================================================================*/
void ThirdBeast::handle_match_over() {
    delete_boards();
    return;

}

/*================================================================================
 * This function sets up all boards at the beginning of the whole match.
 * Add setup here for any boards you create.
 *================================================================================*/
void ThirdBeast::create_boards() {
    int size = this->board_size;

    // dynamically create an array of pointers.
    this->ship_board = new char*[size];
    this->shot_board = new char*[size];
    //this->prob_board = new int*[size];

    // dynamically allocate memory of size `board_size` for each row.
    for (int i = 0; i < size; i++) {
        this->ship_board[i] = new char[size];
        this->shot_board[i] = new char[size];
        //this->prob_board[i] = new int[size];
    }
    return;
}

/*================================================================================
 * This function resets boards between rounds.
 *================================================================================*/
void ThirdBeast::clear_boards() {
    // assign WATER to the boards

    for (int i = 0; i < this->board_size; i++) {
        for (int j = 0; j < this->board_size; j++) {
            this->ship_board[i][j] = WATER;
            this->shot_board[i][j] = WATER;
           // this->prob_board[i][j] = 0;
        }
    }
    return;
}

/*================================================================================
 * This function is called by the AI's destructor and runs at the end of the entire match.
 *================================================================================*/
void ThirdBeast::delete_boards() {
    // deallocates memory using the delete operator

    for (int i = 0; i < this->board_size; i++) {
        delete[] this->ship_board[i];
        delete[] this->shot_board[i];
       // delete[] this->prob_board[i];
    }
    delete[] this->ship_board;
    delete[] this->shot_board;
  //  delete[] this->prob_board;
    return;
}

